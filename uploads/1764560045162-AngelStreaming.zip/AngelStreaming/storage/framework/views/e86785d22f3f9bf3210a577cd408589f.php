<?php $__env->startSection('content'); ?>
<div class="px-6 py-10 max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold text-white mb-6">Edit Movie</h2>

    <?php if($errors->any()): ?>
        <div class="mb-4 bg-red-600 text-white p-4 rounded">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.movies.update', $movie->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="block text-sm font-medium text-white">Title</label>
            <input type="text" name="title" value="<?php echo e(old('title', $movie->title)); ?>"
                class="w-full px-4 py-2 rounded bg-gray-800 border border-gray-600 text-white" required>
        </div>
        <div>
            <label class="block text-sm font-medium text-white">Description</label>
            <textarea name="description" rows="4"
                class="w-full px-4 py-2 rounded bg-gray-800 border border-gray-600 text-white"
                required><?php echo e(old('description', $movie->description)); ?></textarea>
        </div>
        <div>
            <label class="block text-sm font-medium text-white">Genre</label>
            <input type="text" name="genre" value="<?php echo e(old('genre', $movie->genre)); ?>"
                class="w-full px-4 py-2 rounded bg-gray-800 border border-gray-600 text-white" required>
        </div>
        <div>
            <label class="block text-sm font-medium text-white">Release Year</label>
            <input type="number" name="release_year" value="<?php echo e(old('release_year', $movie->release_year)); ?>"
                class="w-full px-4 py-2 rounded bg-gray-800 border border-gray-600 text-white" required>
        </div>
        <div>
            <label class="block text-sm font-medium text-white">Duration</label>
            <input type="text" name="duration" value="<?php echo e(old('duration', $movie->duration)); ?>"
                class="w-full px-4 py-2 rounded bg-gray-800 border border-gray-600 text-white" required>
        </div>
        <div>
            <label class="block text-sm font-medium text-white">Image URL</label>
            <input type="text" name="image" value="<?php echo e(old('image', $movie->image)); ?>"
                class="w-full px-4 py-2 rounded bg-gray-800 border border-gray-600 text-white">
        </div>
        <div>
            <label class="block text-sm font-medium text-white">Video Path</label>
            <input type="text" name="video_path" value="<?php echo e(old('video_path', $movie->video_path)); ?>"
                class="w-full px-4 py-2 rounded bg-gray-800 border border-gray-600 text-white">
        </div>

        <div class="text-right">
            <button type="submit"
                class="px-6 py-2 rounded bg-[#9ABAFF] text-white font-semibold hover:bg-[#b1c6ff] transition">
                Update Movie
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\AngelStreaming\resources\views/admin/movies/edit.blade.php ENDPATH**/ ?>