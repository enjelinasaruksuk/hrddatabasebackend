<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6 text-white">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Manage Movies</h1>
        <a href="<?php echo e(route('admin.movies.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md">Add New Movie</a>
    </div>

    <table class="w-full table-auto border-collapse">
        <thead>
            <tr class="bg-gray-700">
                <th class="border px-4 py-2">Title</th>
                <th class="border px-4 py-2">Genre</th>
                <th class="border px-4 py-2">Year</th>
                <th class="border px-4 py-2">Duration</th>
                <th class="border px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b border-gray-600">
                <td class="px-4 py-2"><?php echo e($movie->title); ?></td>
                <td class="px-4 py-2"><?php echo e($movie->genre); ?></td>
                <td class="px-4 py-2"><?php echo e($movie->release_year); ?></td>
                <td class="px-4 py-2"><?php echo e($movie->duration); ?></td>
                <td class="px-4 py-2 flex gap-2">
                    <a href="<?php echo e(route('admin.movies.edit', $movie->id)); ?>" class="text-blue-400 hover:underline">Edit</a>
                    <form action="<?php echo e(route('admin.movies.destroy', $movie->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-500 hover:underline">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\AngelStreaming\resources\views/admin/movies/index.blade.php ENDPATH**/ ?>