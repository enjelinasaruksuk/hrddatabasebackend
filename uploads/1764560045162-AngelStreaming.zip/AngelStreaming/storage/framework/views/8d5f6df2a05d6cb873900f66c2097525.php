<section class="banner-section relative w-full h-screen overflow-hidden">
    <div id="bannerContainer" class="absolute inset-0 flex">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="absolute inset-0 w-full h-full <?php echo e($i === 0 ? 'opacity-100' : 'opacity-0'); ?> transition-opacity duration-1000" id="slide-<?php echo e($i); ?>">
            <div class="w-full h-full">
                <img src="<?php echo e($banner['image']); ?>" alt="<?php echo e($banner['title']); ?>" class="w-full h-full object-cover" />
            </div>
            <div class="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent flex items-center">
                <div class="ml-24 max-w-2xl">
                    <p class="uppercase text-sm text-[#9ABAFF] font-semibold tracking-wider"><?php echo e($banner['category']); ?></p>
                    <h1 class="text-6xl font-bold mt-2 text-[#9ABAFF] banner-text-shadow"><?php echo e($banner['title']); ?></h1>
                    <div class="flex items-center gap-4 mt-4 text-gray-300 banner-text-shadow">
                        <span class="text-lg"><?php echo e($banner['year']); ?></span>
                        <span>•</span>
                        <span><?php echo e($banner['duration']); ?></span>
                        <span>•</span>
                        <span class="px-3 py-1 border-2 rounded-full border-[#9ABAFF] text-[#9ABAFF] text-sm font-semibold"><?php echo e($banner['genre']); ?></span>
                        <span class="text-yellow-400 text-lg">★ <?php echo e($banner['rating']); ?></span>
                    </div>
                    <p class="mt-6 text-lg leading-relaxed banner-text-shadow text-white"><?php echo e($banner['desc']); ?></p>
                    <div class="mt-8 flex gap-4 banner-text-shadow">
                        <button class="bg-white text-black px-8 py-3 rounded-lg hover:bg-gray-200 transition-all duration-200 font-semibold text-lg flex items-center gap-2">
                            <span>▶</span> Watch Now
                        </button>
                        <button class="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white hover:text-black transition-all duration-200 font-semibold text-lg flex items-center gap-2">
                            <span>+</span> My List
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- Indicators -->
    <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex gap-3">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="indicator-<?php echo e($i); ?>" class="w-3 h-3 rounded-full <?php echo e($i === 0 ? 'bg-[#9ABAFF]' : 'bg-white/30'); ?> cursor-pointer transition-all duration-300"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH C:\laragon\www\AngelStreaming\resources\views/components/banner.blade.php ENDPATH**/ ?>