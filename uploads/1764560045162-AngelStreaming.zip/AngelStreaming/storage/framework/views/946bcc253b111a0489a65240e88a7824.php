<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>AngelStream - Register</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background: #000000;
      font-family: 'Segoe UI', sans-serif;
    }
    .wave-shape {
      border-top-right-radius: 80% 50%;
      border-bottom-right-radius: 80% 50%;
    }
  </style>
</head>
<body class="flex items-center justify-center min-h-screen bg-black">

  <div class="w-full max-w-5xl bg-[#0e0e0e] rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
    <!-- Left Side Form -->
    <div class="w-full md:w-1/2 p-10 text-white flex flex-col justify-center">
      <div class="mb-8">
        <span class="inline-block w-4 h-4 bg-[#9ABAFF] rounded-full mb-4"></span>
        <h1 class="text-3xl font-bold text-[#9ABAFF] mb-2">Register to <span class="text-white">AngelStream</span></h1>
        <p class="text-sm text-gray-400">Sign up to get started</p>
      </div>

      <!-- Laravel validation errors -->
      <?php if($errors->any()): ?>
        <div class="mb-4 text-red-500">
          <ul class="list-disc pl-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-6">
          <label for="name" class="block text-sm mb-2">Name</label>
          <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>"
                class="w-full px-4 py-3 bg-transparent border border-gray-600 rounded-md text-sm placeholder-gray-500 focus:outline-none focus:border-[#9ABAFF]"
                placeholder="Your Name" required autofocus autocomplete="name" />
        </div>

        <div class="mb-6">
          <label for="email" class="block text-sm mb-2">Email</label>
          <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
                class="w-full px-4 py-3 bg-transparent border border-gray-600 rounded-md text-sm placeholder-gray-500 focus:outline-none focus:border-[#9ABAFF]"
                placeholder="you@example.com" required autocomplete="username" />
        </div>

        <div class="mb-6">
          <label for="password" class="block text-sm mb-2">Password</label>
          <input type="password" id="password" name="password"
                class="w-full px-4 py-3 bg-transparent border border-gray-600 rounded-md text-sm placeholder-gray-500 focus:outline-none focus:border-[#9ABAFF]"
                placeholder="Minimum 8 characters" required autocomplete="new-password" />
        </div>

        <div class="mb-6">
          <label for="password_confirmation" class="block text-sm mb-2">Confirm Password</label>
          <input type="password" id="password_confirmation" name="password_confirmation"
                class="w-full px-4 py-3 bg-transparent border border-gray-600 rounded-md text-sm placeholder-gray-500 focus:outline-none focus:border-[#9ABAFF]"
                placeholder="Re-enter your password" required autocomplete="new-password" />
        </div>

        <button type="submit"
                class="w-full py-3 bg-[#9ABAFF] text-black rounded-md font-semibold hover:bg-[#7a98ff] transition duration-300">
          Register
        </button>

        <p class="text-sm text-gray-400 text-center mt-4">
          Already registered?
          <a href="<?php echo e(route('login')); ?>" class="text-[#9ABAFF] hover:underline">Login</a>
        </p>
      </form>
    </div>

    <!-- Right Side Illustration -->
    <div class="hidden md:block md:w-1/2 relative bg-[#111111] wave-shape">
      <img src="https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExNzN1czBtZnZha2tvMjMzbGtsZjRjcXlhNDM2OTFvcDg0aDdzZWx6byZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/v0VoVGS0KrJZf1Yz6L/giphy.gif" alt="Illustration" class="w-full h-full object-cover opacity-90">
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\AngelStreaming\resources\views/auth/register.blade.php ENDPATH**/ ?>